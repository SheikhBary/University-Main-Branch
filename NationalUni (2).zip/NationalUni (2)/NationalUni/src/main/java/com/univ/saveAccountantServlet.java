package com.univ;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class adminLoginServlet
 */
@WebServlet("/saveAccountantServlet")
public class saveAccountantServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public saveAccountantServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

		Accountant a = new Accountant();
		a.setId(Integer.parseInt(request.getParameter("id")));
		a.setEmail(request.getParameter("email"));
		a.setFirstName(request.getParameter("fName"));
		a.setLastName(request.getParameter("lName"));
		a.setPhone(Integer.parseInt(request.getParameter("phone")));
		a.setDeptId(Integer.parseInt(request.getParameter("dept")));
		
		if(a.getId()==0)
			UnivDao.createAccountant(a);
		else
			UnivDao.updateAccountant(a);
		
		request.getRequestDispatcher("viewAccountants.jsp").include(request, response);  
          
	}

}

package com.univ;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class DbOperations {

	static Session sessionObj;
	static SessionFactory sessionFactoryObj;

	// This Method Is Used To Create The Hibernate's SessionFactory Object
	private static SessionFactory buildSessionFactory() {
		// Creating Configuration Instance & Passing Hibernate Configuration File
		Configuration configObj = new Configuration();
		File f = new File("C:\\Users\\Sheik\\Downloads\\NationalUni (3)\\NationalUni\\src\\hibernate.cfg.xml");
		configObj.configure(f);

		// Since Hibernate Version 4.x, ServiceRegistry Is Being Used
		ServiceRegistry serviceRegistryObj = new StandardServiceRegistryBuilder().applySettings(configObj.getProperties()).build(); 

		// Creating Hibernate SessionFactory Instance
		sessionFactoryObj = configObj.buildSessionFactory(serviceRegistryObj);
		return sessionFactoryObj;
	}


	@SuppressWarnings("unchecked")
	public static List<Department> getDepartments() {
		List<Department> deptList = new ArrayList<Department>();		
		try {
			// Getting Session Object From SessionFactory
			sessionObj = buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();

			deptList = sessionObj.createQuery("FROM Department").list();
		} catch(Exception sqlException) {
			System.out.println("Error: " + sqlException);
			sqlException.printStackTrace();
			if(null != sessionObj.getTransaction()) {
				sessionObj.getTransaction().rollback();
			}
		} finally {
			if(sessionObj != null) {
				sessionObj.close();
			}
		}
		return deptList;
	}

	@SuppressWarnings("unchecked")
	public static List<Student> getStudents(int deptId) {
		List<Student> stu = new ArrayList<Student>();		
		try {
			// Getting Session Object From SessionFactory
			sessionObj = buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();

			stu = sessionObj.createQuery("FROM Student as st inner join fetch st.dept dp where dp.id="+deptId).list();
		} catch(Exception sqlException) {
			System.out.println("Error: " + sqlException);
			sqlException.printStackTrace();
			if(null != sessionObj.getTransaction()) {
				sessionObj.getTransaction().rollback();
			}
		} finally {
			if(sessionObj != null) {
				sessionObj.close();
			}
		}
		return stu;
	}
	
	//This method is to get students with outstanding Amount
	@SuppressWarnings("unchecked")
	public static List<Student> getStudentsByFee(int deptId) {
		List<Student> stu = new ArrayList<Student>();		
		try {
			// Getting Session Object From SessionFactory
			sessionObj = buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();

			stu = sessionObj.createQuery("FROM Student as st inner join fetch st.dept dp where st.due>0 and dp.id="+deptId).list();
		} catch(Exception sqlException) {
			System.out.println("Error: " + sqlException);
			sqlException.printStackTrace();
			if(null != sessionObj.getTransaction()) {
				sessionObj.getTransaction().rollback();
			}
		} finally {
			if(sessionObj != null) {
				sessionObj.close();
			}
		}
		return stu;
	}
	
	// This Method Used To Create A New Student Record In The Database Table
		public static void createStudent(Student s) {
			try {
				// Getting Session Object From SessionFactory
				sessionObj = buildSessionFactory().openSession();
				// Getting Transaction Object From Session Object
				sessionObj.beginTransaction();

				sessionObj.save(s);
				sessionObj.getTransaction().commit();
				System.out.println("\nSuccessfully Created Record In The Database!!\n");

			}catch (Exception e)
			{
				System.out.println(e);
			}
		}
				

		public static void updateStudent(Student s) {		
			try {
				// Getting Session Object From SessionFactory
				sessionObj = buildSessionFactory().openSession();
				// Getting Transaction Object From Session Object
				sessionObj.beginTransaction();

				// Creating Transaction Entity
				Student stuObj = (Student) sessionObj.get(Student.class, s.getId());
				stuObj.setAge(s.getAge());
//				stuObj.setDept(s.getDept());
				stuObj.setDue(s.getDue());
				stuObj.setEmail(s.getEmail());
				stuObj.setFirstName(s.getFirstName());
				stuObj.setLastName(s.getLastName());
				stuObj.setPaid(s.getPaid());
				stuObj.setPhone(s.getPhone());
				stuObj.setSex(s.getSex());
				stuObj.setTotalFee(s.getTotalFee());
				
				// Committing The Transactions To The Database
				sessionObj.getTransaction().commit();
				//logger.info("\nStudent With Id?= " + id + " Is Successfully Updated In The Database!\n");
			} catch(Exception sqlException) {
				if(null != sessionObj.getTransaction()) {
					//logger.info("\n.......Transaction Is Being Rolled Back.......\n");
					sessionObj.getTransaction().rollback();
				}
				sqlException.printStackTrace();
			} finally {
				if(sessionObj != null) {
					sessionObj.close();
				}
			}
		}


		// This Method Is Used To Delete A Particular Record From The Database Table
		public static void deleteStudent(Integer id) {
			try {
				// Getting Session Object From SessionFactory
				sessionObj = buildSessionFactory().openSession();
				// Getting Transaction Object From Session Object
				sessionObj.beginTransaction();

				Student studObj = findStudentById(id);
				sessionObj.delete(studObj);

				// Committing The Transactions To The Database
				sessionObj.getTransaction().commit();
				//logger.info("\nStudent With Id?= " + student_id + " Is Successfully Deleted From The Database!\n");
			} catch(Exception sqlException) {
				if(null != sessionObj.getTransaction()) {
					//logger.info("\n.......Transaction Is Being Rolled Back.......\n");
					sessionObj.getTransaction().rollback();
				}
				sqlException.printStackTrace();
			} finally {
				if(sessionObj != null) {
					sessionObj.close();
				}
			}
		}


		//  This Method To Find Particular Record In The Database Table
		public static Student findStudentById(Integer id) {
			Student findStudentObj = null;
			try {
				// Getting Session Object From SessionFactory
				sessionObj = buildSessionFactory().openSession();
				// Getting Transaction Object From Session Object
				sessionObj.beginTransaction();

				findStudentObj = (Student) sessionObj.load(Student.class, id);
			} catch(Exception sqlException) {
				if(null != sessionObj.getTransaction()) {
					//logger.info("\n.......Transaction Is Being Rolled Back.......\n");
					sessionObj.getTransaction().rollback();
				}
				sqlException.printStackTrace();
			} 
			return findStudentObj;
		}

		//  This Method To Find Particular Record In The Database Table
		public static Department findDepartmentById(int deptId) {
			Department deptObj = null;
			try {
				// Getting Session Object From SessionFactory
				sessionObj = buildSessionFactory().openSession();
				// Getting Transaction Object From Session Object
				sessionObj.beginTransaction();

				deptObj = (Department) sessionObj.load(Department.class, deptId);
			} catch(Exception sqlException) {
				if(null != sessionObj.getTransaction()) {
					//logger.info("\n.......Transaction Is Being Rolled Back.......\n");
					sessionObj.getTransaction().rollback();
				}
				sqlException.printStackTrace();
			} 
			return deptObj;
		}


}